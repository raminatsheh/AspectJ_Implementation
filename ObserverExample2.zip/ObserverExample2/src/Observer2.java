
public class Observer2 {


}
