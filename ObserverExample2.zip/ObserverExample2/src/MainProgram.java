
public class MainProgram {

	
	
	
	
	public static void main(String[] args) {
		
		Subject Subject1 = new Subject();
		Observer1 Obs1 = new Observer1();
		Observer2 Obs2 = new Observer2();
		Subject1.attach(Obs1);
		Subject1.attach(Obs2);
		
		Subject1.start();
		

	}
	
	
	
	


}
