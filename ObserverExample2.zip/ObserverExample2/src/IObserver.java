
public interface IObserver {

	public void Update(int State);

	
}
