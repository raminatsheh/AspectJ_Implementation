
public class Observer1 {
	

}
