
public class Point {
	// Define the point location using X and Y coordinates
	private int X;
	private int Y;
	// Define the Lock properties for each point
	public boolean Locked = false;
	
	
	//Constructor for the Point class
	public Point(int tempx, int tempy)
	{
		this.X = tempx;
		this.Y = tempy;
	}
	
	//Get the Value of X and Y and assigning them.
	public int getX()
	{
		return X; 
	}
	public int getY()
	{
		return Y; 
	}
	public void assignX(int tempx)
	{
		this.X = tempx;
	}
	public void assignY(int tempy)
	{
		this.Y = tempy;
	}

}
