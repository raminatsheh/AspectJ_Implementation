import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;



public class MainProgram {
	
	
	//Build the Display
	static Display display  = new Display();
	public static Shell shell = new Shell(display);
	public static Button button1 = new Button(shell, SWT.PUSH);
    public static Button button2 = new Button(shell, SWT.PUSH);
    public static Button button3 = new Button(shell, SWT.PUSH);
    public static Button button4 = new Button(shell, SWT.PUSH);
    public static Button button5 = new Button(shell, SWT.PUSH);

	//Define one map and two Robots
	
	static public Map MyMap = new Map();
	static public Robot Robot1 = new Robot(0,4, button1);
	static public Robot Robot2 = new Robot(3,4, button2);
	static public Robot Robot3 = new Robot(2,4, button3);
	static public Robot Robot4 = new Robot(0,2, button4);
	static public Robot Robot5 = new Robot(2,1, button5);
	
	
	
	
	public static void main(String[] args) {
		
		
		shell.setText("Robots_Moving");
		shell.setBounds(400, 250, 300,300);

	    button1.setText("1");
	    button1.setBounds(Robot1.CurrentLocation.getX(),Robot1.CurrentLocation.getY(),20, 20);
	    button2.setText("2");
	    button2.setBounds(Robot2.CurrentLocation.getX(),Robot2.CurrentLocation.getY(),20, 20);
	    button3.setText("3");
	    button3.setBounds(Robot3.CurrentLocation.getX(),Robot3.CurrentLocation.getY(),20, 20);
	    button4.setText("4");
	    button4.setBounds(Robot4.CurrentLocation.getX(),Robot4.CurrentLocation.getY(),20, 20);
	    button5.setText("5");
	    button5.setBounds(Robot5.CurrentLocation.getX(),Robot5.CurrentLocation.getY(),20, 20);
	    shell.open();
	    
		// Start the Robots thread on both Robots

		Robot1.start();
		Robot2.start();
		Robot3.start();
		Robot4.start();
		Robot5.start();
		
	    shell.open();
	    
		while (Robot5.isAlive())
		{
			
			Robot1.CurrentButton.setBounds(Robot1.CurrentLocation.getX()*20,Robot1.CurrentLocation.getY()*20, 20, 20);
			display.update();
			Robot2.CurrentButton.setBounds(Robot2.CurrentLocation.getX()*20,Robot2.CurrentLocation.getY()*20, 20, 20);
			display.update();
			Robot3.CurrentButton.setBounds(Robot3.CurrentLocation.getX()*20,Robot3.CurrentLocation.getY()*20, 20, 20);
			display.update();
			Robot4.CurrentButton.setBounds(Robot4.CurrentLocation.getX()*20,Robot4.CurrentLocation.getY()*20, 20, 20);
			display.update();
			Robot5.CurrentButton.setBounds(Robot5.CurrentLocation.getX()*20,Robot5.CurrentLocation.getY()*20, 20, 20);
			display.update();
		
		}
		
			   while (!shell.isDisposed()) {

				      if (!display.readAndDispatch())
				        display.sleep();
				    }
				    display.dispose();
	}
			
		
		

	}

	

