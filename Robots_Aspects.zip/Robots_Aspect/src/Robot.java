import org.eclipse.swt.widgets.*;

public class Robot extends Thread{

	// Define the current Location Point
	public Point CurrentLocation = new Point(0,0);
	Point OldLocation = CurrentLocation;

	static Map CurrentMap;
	public Button CurrentButton; 
	boolean UpdateDisplay = true;
	
	public void run() 
	{
		for (int Iteration = 0; Iteration < 20; Iteration++)
		{
			OldLocation = CurrentLocation;

			CurrentLocation = MainProgram.MyMap.MoveRobotUnSynchronized(CurrentLocation);


		System.out.print(CurrentLocation.getX());
		
		System.out.println(CurrentLocation.getY());
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		System.out.println(this.getName().toString());
		}

	}
	
	public Robot (int X, int Y, Button button){
		CurrentLocation.assignX(X);
		CurrentLocation.assignY(Y);
		//MainProgram.MyMap.GetLock(CurrentLocation, OldLocation );
		CurrentButton = button;
		
	}
	
	public Robot (int X, int Y){
		CurrentLocation.assignX(X);
		CurrentLocation.assignY(Y);

		
	}

}
