import java.util.*;

public class Map {
	// Define Map size
	int MapSizeX = 5;
	int MapSizeY = 5;
	
	// Define the Random Number Generator
	static private Random RandomGenerator = new Random();
	
	// Define the Points that the Robot can move on
	public Point[][] Points = new Point[MapSizeX][MapSizeY];
	
	public Map()
	{
		// Populate the Points in the map
		for (int Xtemp = 0; Xtemp < MapSizeX ; Xtemp++ )
		{
			for (int Ytemp = 0; Ytemp < MapSizeY; Ytemp++)
			{
				Points[Xtemp][Ytemp] = new Point(Xtemp,Ytemp);			
			}
		}
	}
	
	// Define a method that returns the next X and Y coordinates
	// by making sure that the lie on the map
	public int GetNextXCoordinates(Point CurrentPoint)
	{
		int newX = CurrentPoint.getX();
		int Modifier = RandomGenerator.nextInt(3)- 1;
		
		if (newX <= 0)
		{
			if (Modifier == -1)
			{
				newX = 0;
			}
			else
			{
				newX = newX + Modifier;
			}
		}		
		else if (newX >= (MapSizeX -1))
		{
			if (Modifier == 1)
			{
				newX = MapSizeX -1;
			}
			else
			{
				newX = newX + Modifier;
			}
			
			if (newX > MapSizeX - 1)
			{
				newX = MapSizeX -1;
			}
		}
		else if (newX > (MapSizeX -1))
		{
			newX = MapSizeX - -1;
		}
		else
		{
			newX = newX + Modifier;
		}
	
		return newX;
	}
	
	public int GetNextYCoordinates(Point CurrentPoint)
	{
		int newY = CurrentPoint.getY();
		int Modifier = RandomGenerator.nextInt(3)- 1;
		
		if (newY <= 0)
		{
			if (Modifier == -1)
			{
				newY = 0;
			}
			else
			{
				newY = newY + Modifier;
			}
		}
		else if (newY >= (MapSizeY -1))
		{
			if (Modifier == 1)
			{
				newY = MapSizeY -1;
			}
			else
			{
				newY = newY + Modifier;
			}
			if (newY > MapSizeY)
			{
				newY = MapSizeY -1;
			}
		}
		else
		{
			newY = newY + Modifier;
		}
		return newY;
	}

	public synchronized Point MoveRobotSynchronized(Point CurrentLocation, Point OldLocation)
	{
		boolean status = true;
		while(status)
		{
			// Find the new Coordinates
			int X = GetNextXCoordinates(CurrentLocation);
			int Y = GetNextYCoordinates(CurrentLocation);
		
			if (Points[X][Y].Locked)
			{
				status = true;
			}
			else
			{
				Points[X][Y].Locked = true;
				Points[OldLocation.getX()][OldLocation.getY()].Locked = false;
				CurrentLocation.assignX(X);
				CurrentLocation.assignY(Y);
				status = false;
			}
		}

		
		return CurrentLocation;
	}
	
	public Point MoveRobotUnSynchronized(Point CurrentLocation)
	{
	
		
		
			// Find the new Coordinates
			int X = GetNextXCoordinates(CurrentLocation);
			int Y = GetNextYCoordinates(CurrentLocation);
		
		
				
				
				CurrentLocation.assignX(X);
				CurrentLocation.assignY(Y);
				
			
		

		
		return CurrentLocation;
	}

}
