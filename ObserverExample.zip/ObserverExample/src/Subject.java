import java.util.Random;

public class Subject extends Thread{
	
	public Simulator Randomint = new Simulator();
	
	static public int State = 0;
	
	public int GetState(){
		return this.State;
	}
	public void SetState(int State){
		this.State = State;
	}
	
	public void run(){
		
		for (int temp = 0; temp < 10; temp++){
				
			SetState(Randomint.GetInt());
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("New Subject State is:"+this.State);
		}
	}
	
	public class Simulator {
		
	       public int GetInt (  ) {
	         
	    	   Random random = new Random();
	    	   return random.nextInt(5);
	       }
	     }
}
