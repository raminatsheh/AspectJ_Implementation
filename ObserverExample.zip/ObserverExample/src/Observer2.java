
public class Observer2 {

	//static public int State = 0;
	/*public void setSubject(ISubject S){
		
	}
	public void setSubject(){
		
	}*/
}
